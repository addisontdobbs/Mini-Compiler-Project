%{
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

void yyerror(const char *s);
int yylex();

/* Output suppression counter.  suppress > 0 silences all output. */
static int suppress = 0;

/* Variable table (up to 64 named variables) */
#define VAR_TABLE_SIZE 64
typedef struct { char name[64]; double value; } Variable;
static Variable var_table[VAR_TABLE_SIZE];
static int      var_count = 0;

double get_var(const char *name) {
    int i;
    for (i = 0; i < var_count; i++)
        if (strcmp(var_table[i].name, name) == 0)
            return var_table[i].value;
    fprintf(stderr, "Warning: undefined variable '%s', using 0\n", name);
    return 0.0;
}

double set_var(const char *name, double val) {
    int i;
    for (i = 0; i < var_count; i++) {
        if (strcmp(var_table[i].name, name) == 0) {
            var_table[i].value = val;
            return val;
        }
    }
    if (var_count < VAR_TABLE_SIZE) {
        strncpy(var_table[var_count].name, name, 63);
        var_table[var_count].value = val;
        var_count++;
    } else {
        fprintf(stderr, "Error: variable table full\n");
    }
    return val;
}

/* Helpers used by mid-rule actions */
static double saved_cond; /* stash the if-condition between rules */
%}

%union {
    double  dval;
    char   *sval;
}

%token <dval> NUMBER
%token <sval> IDENT
%token SIN COS TAN LOG EXP SQRT ABS
%token IF ELSE WHILE FOR SWITCH CASE DEFAULT BREAK PRINT
%token PLUS MINUS MUL DIV MOD POW
%token EQ NEQ GT GTE LT LTE AND OR NOT
%token ASSIGN COLON
%token LPAREN RPAREN LBRACE RBRACE SEMI

%type <dval> expr stmt stmts if_cond

/* Operator precedence (lowest to highest) */
%right ASSIGN
%left  OR
%left  AND
%right NOT
%left  EQ NEQ
%left  GT GTE LT LTE
%left  PLUS MINUS
%left  MUL DIV MOD
%right UMINUS
%right POW

/* Standard dangling-else resolution: prefer shifting ELSE */
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

program:
    stmts
;

stmts:
    stmts stmt      { $$ = $2; }
  | /* empty */     { $$ = 0;  }
;

/*
 * if_cond reduces the condition and immediately toggles suppress.
 * By making this a separate non-terminal with its own $$ value,
 * we avoid placing a mid-rule action before 'stmts', which was
 * the source of all reduce/reduce conflicts.
 */
if_cond:
    IF LPAREN expr RPAREN {
        $$ = $3;
        saved_cond = $3;
        if (!(int)$3) suppress++;   /* suppress body if condition is false */
    }
;

stmt:
    expr SEMI {
        if (!suppress) printf("= %.6g\n", $1);
        $$ = $1;
    }
  | IDENT ASSIGN expr SEMI {
        set_var($1, $3);
        if (!suppress) printf("%s = %.6g\n", $1, $3);
        free($1);
        $$ = $3;
    }
  | PRINT expr SEMI {
        if (!suppress) printf("%.6g\n", $2);
        $$ = $2;
    }

  /* if without else */
  | if_cond LBRACE stmts RBRACE %prec LOWER_THAN_ELSE {
        if (!(int)$1) suppress--;   /* restore after body */
        $$ = $1;
    }

  /* if with else */
  | if_cond LBRACE stmts RBRACE ELSE {
        if (!(int)$1) suppress--;   /* done suppressing if-body */
        if ( (int)$1) suppress++;   /* now suppress else-body */
    }
    LBRACE stmts RBRACE {
        if ((int)$1) suppress--;    /* done suppressing else-body */
        $$ = (int)$1 ? $3 : $8;
    }

  /* while loop */
  | WHILE LPAREN expr RPAREN LBRACE stmts RBRACE {
        /*
         * Body is evaluated once during single-pass reduction.
         * Full iteration requires an AST (see Limitations in report).
         */
        if (!suppress) {
            if ($3)
                printf("[while] condition true; body evaluated (result: %.6g)\n", $6);
            else
                printf("[while] condition false; body skipped\n");
        }
        $$ = $6;
    }

  /* for loop */
  | FOR LPAREN for_init SEMI expr SEMI for_update RPAREN LBRACE stmts RBRACE {
        /*
         * Grammar fully recognises for-loop syntax.
         * Body executes once during single-pass reduction.
         * Full iteration requires an AST (see Limitations in report).
         */
        if (!suppress) {
            if ($5)
                printf("[for] condition true; body evaluated (result: %.6g)\n", $10);
            else
                printf("[for] condition false; body skipped\n");
        }
        $$ = $10;
    }

  /* switch / case / default */
  | SWITCH LPAREN expr RPAREN LBRACE case_clauses RBRACE {
        if (!suppress)
            printf("[switch] on value: %.6g\n", $3);
        $$ = $3;
    }

  /* bare block */
  | LBRACE stmts RBRACE {
        $$ = $2;
    }
;

for_init:
    IDENT ASSIGN expr { set_var($1, $3); free($1); }
  | expr              { }
  | /* empty */       { }
;

for_update:
    IDENT ASSIGN expr { set_var($1, $3); free($1); }
  | expr              { }
  | /* empty */       { }
;

case_clauses:
    case_clauses CASE NUMBER COLON stmts { }
  | case_clauses DEFAULT COLON stmts     { }
  | /* empty */                          { }
;

expr:
    NUMBER                              { $$ = $1; }
  | IDENT                               { $$ = get_var($1); free($1); }

  /* Arithmetic */
  | expr PLUS  expr                     { $$ = $1 + $3; }
  | expr MINUS expr                     { $$ = $1 - $3; }
  | expr MUL   expr                     { $$ = $1 * $3; }
  | expr DIV   expr                     {
        if ($3 == 0) { fprintf(stderr, "Error: division by zero\n"); $$ = 0; }
        else         { $$ = $1 / $3; }
    }
  | expr MOD   expr                     {
        if ((int)$3 == 0) { fprintf(stderr, "Error: modulo by zero\n"); $$ = 0; }
        else              { $$ = (double)((long long)$1 % (long long)$3); }
    }
  | expr POW   expr                     { $$ = pow($1, $3); }
  | MINUS expr %prec UMINUS             { $$ = -$2; }

  /* Comparison */
  | expr EQ  expr                       { $$ = ($1 == $3) ? 1 : 0; }
  | expr NEQ expr                       { $$ = ($1 != $3) ? 1 : 0; }
  | expr GT  expr                       { $$ = ($1 >  $3) ? 1 : 0; }
  | expr GTE expr                       { $$ = ($1 >= $3) ? 1 : 0; }
  | expr LT  expr                       { $$ = ($1 <  $3) ? 1 : 0; }
  | expr LTE expr                       { $$ = ($1 <= $3) ? 1 : 0; }

  /* Logical */
  | expr AND expr                       { $$ = ($1 && $3) ? 1 : 0; }
  | expr OR  expr                       { $$ = ($1 || $3) ? 1 : 0; }
  | NOT  expr                           { $$ = !$2; }

  /* Trigonometric */
  | SIN  LPAREN expr RPAREN             { $$ = sin($3); }
  | COS  LPAREN expr RPAREN             { $$ = cos($3); }
  | TAN  LPAREN expr RPAREN             { $$ = tan($3); }

  /* Other math */
  | LOG  LPAREN expr RPAREN             {
        if ($3 <= 0) { fprintf(stderr, "Error: log of non-positive number\n"); $$ = 0; }
        else         { $$ = log($3); }
    }
  | EXP  LPAREN expr RPAREN             { $$ = exp($3); }
  | SQRT LPAREN expr RPAREN             {
        if ($3 < 0) { fprintf(stderr, "Error: sqrt of negative number\n"); $$ = 0; }
        else        { $$ = sqrt($3); }
    }
  | ABS  LPAREN expr RPAREN             { $$ = fabs($3); }

  | LPAREN expr RPAREN                  { $$ = $2; }
;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Parse error: %s\n", s);
}
