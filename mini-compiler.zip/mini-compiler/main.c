#include <stdio.h>

int yyparse();

int main() {
    printf("=========================================\n");
    printf("   Mini Compiler  (Flex + Bison)\n");
    printf("=========================================\n");
    printf("Supported: arithmetic, trig, sqrt, abs,\n");
    printf("           variables, if/else, while,\n");
    printf("           for, switch/case, print\n");
    printf("End each statement with ';'\n");
    printf("Example: x = 3 * (2 + sin(1.57));\n");
    printf("Press CNTRL D to exit.\n");
    printf("-----------------------------------------\n\n");
    yyparse();
    return 0;
}
